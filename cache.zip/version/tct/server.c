#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int sockfd, newsockfd;
    char buffer[BUFFER_SIZE];
    struct sockaddr_in servaddr, cliaddr;
    socklen_t cliaddr_len = sizeof(cliaddr);
    FILE *fileptr;
    ssize_t bytes_read;

    // Creating socket file descriptor
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));

    // Filling server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);

    // Bind the socket with the server address
    if (bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) == -1) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(sockfd, 5) == -1) {
        perror("listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d...\n", PORT);

    // Accept a new connection
    if ((newsockfd = accept(sockfd, (struct sockaddr *)&cliaddr, &cliaddr_len)) == -1) {
        perror("accept failed");
        exit(EXIT_FAILURE);
    }

    // Open the file to send
    if ((fileptr = fopen("file.txt", "rb")) == NULL) {
        perror("file opening failed");
        exit(EXIT_FAILURE);
    }

    // Read and send the file in chunks
    while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, fileptr)) > 0) {
        if (send(newsockfd, buffer, bytes_read, 0) == -1) {
            perror("send failed");
            exit(EXIT_FAILURE);
        }
    }

    // Close file and sockets
    fclose(fileptr);
    close(newsockfd);
    close(sockfd);

    return 0;
}
